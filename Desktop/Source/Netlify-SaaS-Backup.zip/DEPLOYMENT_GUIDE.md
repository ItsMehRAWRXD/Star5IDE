# Netlify Deployment Guide

## Project Overview
This is a complete SaaS backend with cryptographic API functions, ready for Netlify deployment.

## Files Included
- `netlify.toml` - Netlify configuration
- `package.json` - Node.js dependencies and scripts
- `config.js` - Application configuration
- `env.example` - Environment variables template
- `.gitignore` - Git ignore rules
- `netlify/functions/api.js` - Main serverless function with cryptographic operations
- `src/` - Express.js backend source code
- `public/` - Frontend files
- `NETLIFY_DEPLOYMENT.md` - Detailed deployment instructions

## Quick Start

### 1. Install Dependencies
```bash
npm install
```

### 2. Set Environment Variables
Copy `env.example` to `.env` and fill in your values:
- MongoDB connection string
- JWT secret
- Stripe keys
- Email service credentials

### 3. Deploy to Netlify
- Connect your GitHub repository
- Build command: `npm run build` (or leave empty)
- Publish directory: `public`
- Functions directory: `netlify/functions`

### 4. Test Your API
- Health check: `/.netlify/functions/api/health`
- Encryption: `/.netlify/functions/api/encrypt`
- Decryption: `/.netlify/functions/api/decrypt`
- Hashing: `/.netlify/functions/api/hash`
- Key generation: `/.netlify/functions/api/generate-key`

## Features
- ✅ Rate limiting and security
- ✅ MongoDB integration
- ✅ JWT authentication
- ✅ Stripe payment processing
- ✅ Email services
- ✅ Cryptographic operations
- ✅ CORS support
- ✅ Error handling

## Support
Refer to `NETLIFY_DEPLOYMENT.md` for detailed setup instructions.
